<?php
date_default_timezone_set("Asia/Calcutta");    
include_once("../connection.php");
require_once('includes/header.php');
$ip_address = $_SERVER['REMOTE_ADDR']; 
$date = date('Y-m-d H:i:s');
$sql_statement= "INSERT INTO `tbl_landing_url`( `country_name`, `page_url`, `ip_address`, `date`) VALUES ('".$countryName."','".$_SESSION['REQUEST_URI']."','".$ip_address."','".$date."')";
$result = mysqli_query($conn,$sql_statement);

?>
<style type="text/css">
    #main-dadicated-banner .full-img{
width: 100%;
}
section.main-dadicated-banner {
margin-top: 117px;
position: relative;
padding-top: 0;
padding-bottom: 0;
}
.main-banner-wrapper {
position: absolute;
top: 0;
width: 100%;
height: 100%;
display: flex;
align-items: center;
}
.main-banner-wrapper .container {
display: flex;
justify-content: space-between;
align-items: center;
max-width: 1199px;
}
.banner-containt {
max-width: 805px;
position: relative;
padding: 50px 50px 50px 50px;
z-index: 1;
}
.banner-containt:after {content: "";width: 100%;height: 100%;border: 4px solid rgba(255, 255, 255, 0.51);position: absolute;left: 0;top: 0;max-width: 584px;border-right: 0;z-index: -1;}
.banner-containt h3 {
color: #fff;
font-weight: bold;
font-size: 45px;
line-height: 54px;
margin-bottom: 20px
}
.banner-containt:before{
content: "";
width: 100%;
height: 30px;
border-right: 4px solid rgba(255, 255, 255, 0.51);
position: absolute;
left: 0;
top: 4px;
max-width: 584px; z-index: -1;
}
.banner-containt h3::after {
content: "";
width: 100%;
height: 240px;
border-right: 4px solid rgba(255, 255, 255, 0.51);
position: absolute;
left: 0;
bottom: 4px;
max-width: 584px;
z-index: -1;
}
.banner-containt small {
font-size: 22px;
color: #fff;
max-width: 526px;
width: 100%;
display: block;
margin-bottom: 20px;
}
a.button-main-banner {
background-color: rgb(54, 194, 100);
width: 100%;
height: 42px;
line-height: 42px !important;
text-align: center;
color: #fff !important;
margin-top: 18px;
border: 0 !important;
text-transform: capitalize !important;
letter-spacing: 0.5px;
display: inline-block;
max-width: 270px;
transition: all 0.5s;
}
a.button-main-banner:hover{
background-color: #239b4b;
-webkit-box-shadow: 0px 30px 30px 0px rgba(1, 1, 1, 0.1);
box-shadow: 0px 30px 30px 0px rgba(1, 1, 1, 0.1);
}
.banner-containt ul li {
color: #fff;
font-size: 16px;
font-weight: 500;
line-height: 34px;
padding-left: 39px;
background-image: url(images/tick.png);
background-repeat: no-repeat;
background-position: left center;
}
.banner-containt ul {
margin-bottom: 30px;
}
.commen-section h2{
/*color: #08093a;
font-size: 36px;
font-weight: 500;
margin-bottom: 20px;*/
}
.commen-section h2 small{font-size: 16px; color:#08093a;}
.item-wrapper {
border: 3px solid #e6e6eb;
padding: 40px 30px;
min-height: 340px;
border-radius: 10px;
transition: all 0.5s;
cursor: pointer;
margin: 30px 0;
height: 100%;
max-height: 340px;
}
.item-wrapper h3 {
font-size: 20px;
margin: 23px 0;
}
section.commen-section.hiring-models {
    padding-top: 80px;
} 
.logo-box {
display: flex;
align-items: center;
}
.logo-box li {
padding: 30px;
background-color: #fff;
border: 3px solid #f4f5f9;
margin-right: 15px;
margin-bottom: 15px;
border-radius: 10px;
min-height: 140px;
display: flex;
align-items: center;
justify-content: center;
width: 150px;
}
section.dedicated-developer-logos {
padding: 0;
background-color: #f4f5f9;
position: relative;
z-index: 1;
}
.logo-box li:last-child {
margin-bottom: 0;
}
section.dedicated-developer-logos::after, section.dedicated-developer-logos::before {
width: 100%;
height: 30px;
content: "";
background-color: #fff;
position: absolute;
top: 0;
left: 0;
z-index: -1;
}
section.dedicated-developer-logos::before{
top: auto;
bottom: 0;
}
.item-wrapper:hover {
background-color: #169ef8;
border: 3px solid #169ef8;
}
.commen-section p {
font-size: 16px;
color: #000;
line-height: 28px;
margin-bottom: 15px;
}
.commen-section p:last-child {
margin-bottom: 0;
}
.item-wrapper p {
font-size: 14px;
line-height: 22px;
}
section.hiring-process .container{
max-width: 1250px;
}
.commen-section .blue_big_btn {
width: 100%;
max-width: 240px;
margin-top: 50px;
}
.item-wrapper:hover h3, .item-wrapper:hover p {
color: #fff;
}
.hiring-models h2 {
margin-bottom: 60px;
}
section.hiring-process .logo-box li {
max-width: 194px;
width: 100%;
position: relative;
flex-wrap: wrap;
transition: all 0.5s;
}
section.hiring-process .logo-box li h3 {
font-size: 16px;
text-align: center;
}
.number {
background-color: #169ef8;
position: absolute;
top: -3px;
right: -3px;
width: 25px;
height: 25px;
text-align: center;
line-height: 25px;
font-size: 12px;
color: #fff;
font-weight: 500;
transition: all 0.5s;
}
.icon-hover-change {
background-image: url(images/all-icon-img-5.png);
width: 54px;
height: 54px;
background-size: auto;
margin-bottom: 20px;
}
section.hiring-process .logo-box li:hover {
background-color: #2196f3;border-color: #2196f3; cursor: pointer;
}
section.hiring-process .logo-box li:hover h3, section.hiring-process .logo-box li:hover p{
color: #fff;
}
section.hiring-process .logo-box li:hover .number{
background-color: #c7dbff; color: #1d4e9c;
}
.icon-hover-change.icon-hover-2 {
background-position: 0 -72px;
}
.icon-hover-change.icon-hover-3 {
background-position: 0 -144px;
}
.icon-hover-change.icon-hover-4 {
background-position: 0 -216px;
}
.icon-hover-change.icon-hover-5 {
background-position: 0 -288px;
}
section.hiring-process .logo-box li:hover .icon-hover-1 {
background-position: -65px 0;
}
section.hiring-process .logo-box li:hover .icon-hover-change.icon-hover-2 {
background-position: -65px -72px;
}
section.hiring-process .logo-box li:hover .icon-hover-change.icon-hover-3 {
background-position: -65px -144px;
}
section.hiring-process .logo-box li:hover .icon-hover-change.icon-hover-4 {
background-position: -65px -216px;
}
section.hiring-process .logo-box li:hover .icon-hover-change.icon-hover-5 {
background-position: -65px -288px;
}
section.dedicated-resources-wrapper h2 small {
margin-bottom: 10px;
}
section.dedicated-resources-wrapper h2 {
line-height: 38px;
margin-bottom: 40px;
}
section.dedicated-resources-wrapper ul li {
font-size: 18px;
color: #000000;
font-weight: 500;
line-height: 36px;
position: relative;
padding-left: 30px;
}
section.dedicated-resources-wrapper ul li::after {content: "";width: 9px;height: 9px;position: absolute;border-radius: 100px;border: 1px solid #000;top: 13px;left: 0;}
section.dedicated-resources-wrapper .container{
max-width: 1150px;
}
section.dedicated-resources-wrapper .img-box {
position: absolute;
z-index: -1;
left: -90px;
top: -50px;
}
section.dedicated-resources-wrapper {
background-color: #f4f5f9;
position: relative;
z-index: 1;
padding-top: 120px;
padding-bottom: 0;
}
section.dedicated-resources-wrapper::after {
background-color: #fff;
height: 70px;
position: absolute;
content: "";
width: 100%;
bottom: 0;
z-index: -1;
}
.good-firms p {
font-size: 18px;
max-width: 400px;
margin-bottom: 60px;
}
section.good-firms {
background-color: #f4f5f9;
margin-bottom: 0;
background-image: url(images/object.png);
background-repeat: no-repeat;
background-position: right 60px;
position: relative;
z-index: 1;
}
section.good-firms::after {
content: "";
background-image: url(images/object-1.png);
background-repeat: no-repeat;
background-position: left 230px;
position: absolute;
width: 100%;
height: 100%;
left: auto;
top: 0;
z-index: -2;
}
.good-firms-list {
margin-right: 80px;
}
.commen-hover-box {
background-image: url(images/hiring-models.png);
width: 64px;
height: 58px;
background-size: inherit;
margin-bottom: 20px;
margin-left: auto;
margin-right: auto;
}
.item-wrapper:hover .item-wrapper-hover-1 {
background-position: -82px -1px;
}
.item-wrapper-hover-2 {
background-position: 2px -66px;
width: 68px;
height: 70px;
}
.item-wrapper:hover .item-wrapper-hover-2 {
background-position: 68px -66px;
}
.item-wrapper-hover-3 {
background-position: 2px -136px;
width: 68px;
height: 70px;
}
.item-wrapper:hover .item-wrapper-hover-3 {
background-position: 68px -136px;
}
.item-wrapper-hover-4 {
background-position:2px -214px;
width: 68px;
height: 70px;
}
.item-wrapper:hover .item-wrapper-hover-4 {
background-position: 68px -214px;
}
.item-wrapper:hover {
background-color: #169ef8;
border: 3px solid #169ef8;
box-shadow: 4px 3px 8px rgba(0, 0, 0, 0.27);
}
.popup-bar .modal-dialog {
background-color: #fff;
max-width: 390px;
padding: 30px;
border-radius: 10px;
}
.popup-bar {
margin-top: 80px;padding: 0 15px !important;
}
.popup-bar button.close {
position: static;
padding: 0 !important;
}
.popup-bar .modal-header {
padding: 0;
border: 0;
}
.popup-bar .modal-header button.close {
font-size: 22px;
}
.popup-bar .form-control {
border: 0;
}
.popup-bar .contact-form-error-message span {
margin: 13px 0;
}
.popup-bar .form-control::-webkit-input-placeholder { /* Chrome/Opera/Safari */
color: #333; font-size: 12px; letter-spacing: 0.5px;
}
.popup-bar .form-control::-moz-placeholder { /* Firefox 19+ */
color: #333; font-size: 12px; letter-spacing: 0.5px;
}
.popup-bar .form-control:-ms-input-placeholder { /* IE 10+ */
color: #333; font-size: 12px; letter-spacing: 0.5px;
}
.popup-bar .form-control:-moz-placeholder { /* Firefox 18- */
color: #333; font-size: 12px; letter-spacing: 0.5px;
}
.popup-bar .form-control{
font-size: 14px;
}
.popup-bar .input_white_bg span img {
width: 100%;
}
.popup-bar .input_white_bg.textarea_box {
height: 90px;
}
.popup-bar .small_blue_btn {
    height: 44px;
    line-height: 44px;
    font-size: 14px;
    width: calc(100% - 8px);
    margin: 0 5px;
}
.popup-bar .input_white_bg.textarea_box {
height: 90px;
}
.input_white_bg span {
width: 36px;
padding-right: 14px;
margin-left: 10px;
}
section.dedicated-resources-wrapper button {
    max-width: none !important;
    display: inline-block;
    width: auto !important;
}
.banner-containt button.blue_big_btn {
    background-color: #36c264;
    line-height: 44px;
    height: 44px;
    margin-top: 30px;
}
.form-row_custom h4 {
    font-size: 24px;
    font-weight: 500;
}
.logo-box li img {
    max-width: 70px;
}
.company-logo-slider img {
    max-width: 280px;
    width: 100%;
}
.review-wrap {
    text-align: center;
    margin-top: 19px;
    color: #ffffff;
    font-size: 14px;
    letter-spacing: 1.5px;
}

.review-wrap i {
color: #ffab2e;
    font-size: 18px;
    margin-top: 6px;
    letter-spacing: 0;
}

.review-wrap i:last-child {
color: #ffab2e;
}
section.commen-section.hiring-models .container {
    max-width: 1386px;
}
section.first-month-wrapper .form-group.red_btn {
    background-color: rgb(175 83 43 / 38%);
    padding: 40px 40px;
    max-width: 60%;
    margin: 0 auto;
    border-radius: 10px;
}

section.first-month-wrapper .form-group.red_btn .form-group.red_btn {
    max-width: 100%;
    background-color: transparent;
    padding: 0;
}

section.first-month-wrapper h1 {
    font-size: 24px;
    margin-bottom: 20px;
}
input#dateday, section.first-month-wrapper input {
    border: 0;
    width: 100%;
    padding: 12px 15px;
    color: #000 !important;
    height: auto;
    border-radius: 5px;
}
div#ui-datepicker-div {
    background-color: #fff;
    padding: 10px 20px;
    border-radius: 10px;
    margin-top: 10px;
}

span#datetime {
    width: 100%;
    display: block;
}

span#datetime select#datetimeSlot {
    width: 100%;
    border-radius: 5px;
    padding: 10px 15px;
    color: #000 !important;
}

span#datetime * {
    color: #333 !important;
}
.margin-mobile-bottom{margin-bottom:30px !important;}
.case_studay .project_details p b{font-weight:500;color:#737373;}
.case_studay .scrool_expertise a{font-size:14px;padding:0 20px;line-height:45px;height:45px;}
.margin-mobile-bottom::after{content:"\f10e";font:normal normal normal 44px/1 FontAwesome;position:absolute;bottom:10px;right:40px;color:#e2e2e2;}
.case_study_img{display:-webkit-box;display:-ms-flexbox;display:flex;max-width:100%;margin:0 auto;-webkit-box-pack:center;-ms-flex-pack:center;justify-content:center;-webkit-box-align:self-end;-ms-flex-align:self-end;align-items:center; }
.case_study_img img {
    width: 100%;
}
.case_studay a.small_blue_btn i{margin-right:15px;font-size:24px;}
.case_studay .gray_bg{padding:30px 30px;height: 100%;}
.case_studay h6:first-child{margin-top:0;}
.gray_bg{background-color:#f7f7f9;}
.case_studay .project_details h4 {
font-size: 18px;
    line-height: 25px;
    font-weight: 500;
    }
    section.case_studay .container {
    max-width: 1366px;
}
.blue_big_btn, .small_blue_btn {
    background-color: #2196f3;
    padding: 0 30px;
    height: 52px;
    font-size: 16px;
    color: rgb(255, 255, 255);
    text-align: center;
    line-height: 52px;
    letter-spacing: 0.5px;
    border: 1px solid transparent;
    -webkit-transition: all 0.3s;
    -o-transition: all 0.3s;
    transition: all 0.3s;
    display: inline-block;
    position: relative;
    z-index: 1;
}
.out_line_big_btn{width:200px;height:52px;font-size:16px;color:rgb(36, 45, 52);text-align:center;line-height:53px;letter-spacing:0.5px;border:1px solid #2f353b;margin-left:23px;-webkit-transition:all 0.3s;-o-transition:all 0.3s;transition:all 0.3s;background-color:transparent;}
.blue_big_btn:hover, a.small_blue_btn:hover, button.small_blue_btn:hover{-webkit-box-shadow:none;box-shadow:none;color:#fff;background-color:#077ae6;cursor:pointer;-webkit-box-shadow:0px 30px 30px 0px rgba(1, 1, 1, 0.1);box-shadow:0px 30px 30px 0px rgba(1, 1, 1, 0.1);}
.out_line_big_btn:hover{-webkit-box-shadow:0px 30px 30px 0px rgba(1, 1, 1, 0.1);box-shadow:0px 30px 30px 0px rgba(1, 1, 1, 0.1);color:#fff;border-color:transparent;background-color:rgb(33, 150, 243);}
@media (min-width:992px){

    .case-studies .scrool_expertise{margin-top: 15px;}
}
    .case_studay .project_details h4{margin-top: 15px;}
section.case_studay {
    background-color: #eaeaea;
    padding: 80px 0;
}
@media (max-width: 1600px) {
.banner-containt h3 {
font-size: 36px;
line-height: 40px;
}
.banner-containt small {
font-size: 20px;
}
.banner-containt ul {
margin-bottom: 0;
}
div#main-dadicated-banner img {
max-width: none;
width: auto !important;
height: auto;
}
div#main-dadicated-banner {
overflow: hidden;
height: 650px;
}
.main-banner-wrapper {
padding: 0 30px;
}
/*Mobile*/
}
@media (max-width: 1199px) {
section.dedicated-developer-logos .container, section.hiring-process .container, section.dedicated-resources-wrapper
.container {
padding:0  30px;
}
section.dedicated-developer-logos .commen-section {
padding-left: 70px;
}
section.dedicated-developer-logos::after, section.dedicated-developer-logos::before {
height: 70px;
}
section.hiring-process .logo-box li {
max-width: max-content;
width: auto;
}
section.dedicated-resources-wrapper .img-box + img {
width: 100%;
}
.commen-section h2 {
font-size: 27px;
line-height: 35px;
}
section.good-firms {
padding-left: 0;
padding-right: 0;
}
section.main-dadicated-banner {padding-left: 0;padding-right: 0;}
div#our_parthner_slider .owl-nav {
display: none;
}
.logo-box li {
width: auto;
padding: 15px;
min-height: 110px;
}
section.dedicated-developer-logos::after, section.dedicated-developer-logos::before{display: none;}
section.dedicated-developer-logos {padding: 60px 0;}
section.dedicated-resources-wrapper ul li {
font-size: 14px;
line-height: 22px;
margin-bottom: 20px;
}
section.dedicated-resources-wrapper {overflow: hidden;}
section.dedicated-resources-wrapper ul li::after {
top: 8px;
}
section.dedicated-resources-wrapper::after{display: none}
section.dedicated-resources-wrapper {
padding-bottom: 60px;
}
}
@media (max-width: 767px) {
.commen-section h2 small {
text-align: left;
max-width: 100%;
}
section.dedicated-resources-wrapper .commen-section {
margin-top: 50px;
}
.good-firms p {
max-width: 100%;
margin-bottom: 30px;
}
section.good-firms {
padding-bottom: 50px;
}
.good-firms-list {
margin-right: 0;
text-align: center;
}
section.good-firms .col-md-6.text-right {
order: 2;
margin-top: 50px;
}
section.hiring-process .logo-box li {
min-height: 160px;
max-width: 210px;
}
.logo-box {
flex-direction: column;
width: 100%;
margin-top: 70px;
}
section.hiring-process .logo-box li h3 {
width: 100%;
}
.logo-box ul {
display: flex;
align-items: center;
justify-content: center;
}
section.dedicated-developer-logos .commen-section {
padding-left: 30px;
padding-right: 30px;
}
section.dedicated-developer-logos .container, section.hiring-process .container, section.dedicated-resources-wrapper .container {
padding: 0 15px;
}
.company-logo-slider {
display: none;
}
section.commen-section.hiring-models small {
text-align: center;
}
section.dedicated-developer-logos .logo-box {
margin-top: 0;
}
section.dedicated-developer-logos .logo-box ul {
width: 100%;
}
section.dedicated-developer-logos .logo-box ul li {
width: 170px;
margin-bottom: 20px;
}
section.dedicated-developer-logos .logo-box ul li:last-child {
margin-right: 0;
}
section.hiring-process .logo-box li:last-child {
margin-right: 0;
}
section.good-firms {
background-image: none;
}
.company-logo-slider img {
    max-width: 230px;
    width: 100%;
}
section.first-month-wrapper .form-group.red_btn {
    max-width: 100%;
    padding: 40px 20px;
}
}
@media (max-width: 640px) {
.item-wrapper {min-height: auto;}
section.main-dadicated-banner {margin-top: 91px;}
.banner-containt {
padding:0;
}
.banner-containt h3{
    font-size: 36px;
    line-height: 44px;
}
section.hiring-process .logo-box li {
max-width: 100%;
width: 100%;
margin-right: 0;
margin-bottom: 15px;
}
section.hiring-process .logo-box ul {
flex-wrap: wrap;
}
.banner-containt:after, .banner-containt:before, .banner-containt h3::after {
    display: none;
}
div#main-dadicated-banner {
    height: 550px;
}
}
@media (max-width: 480px) {
.item-wrapper {
min-height: auto;
}
.banner-containt h3{    
font-size: 28px;
    line-height: 38px;
}
.main-banner-wrapper{padding: 15px;}
.banner-containt small {font-size: 16px;}
.banner-containt ul li{font-size: 14px;}
.logo-box li {
width: 100% !important;
margin-right: 0;
}
.logo-box ul {
flex-wrap: wrap;
}
div#main-dadicated-banner {
height: 460px;
}
.good-firms-list img {
max-width: 100%;
}
.commen-section .blue_big_btn {
height: 44px;
line-height: 44px;
max-width: 100%;
margin-top: 20px;
}
}
@media (max-width: 400px) {
div#main-dadicated-banner {
height: 560px;
}
.banner-containt ul li {
    background-position: left 7px;
    padding-left: 20px;
    background-size: 12px;
    line-height: 19px;
    margin-bottom: 15px;
}

.banner-containt ul li:last-child {
    margin-bottom: 0;
}
}
</style>
<section id="home_banner" class="home_banner banner overlay overlay_blue">
    <div class="container text-white">
        <div class="row">
            <div class="col-lg-7 col-md-6 pr-lg-0 d-flex align-items-center">
                <div class="content">
                    <div class="top">
                        <h1 class="text-white">Digitally Transform <br>Your Business</h1>
                        <div class="why_laravel top_new_text">
                            <ul class="halp-blocks row">
                                <li class="col-md-6">Custom Web development</li>
                                <li class="col-md-6">API Development</li>
                                <li class="col-md-6">eCommerce</li>
                                <li class="col-md-6">Front End Development</li>
                                <li class="col-md-6">Full Stack Development</li>
                            </ul>
                            <div class="clients-appreciate">
                                <h6>Clients Appreciate Our</h6>
                                <ul>
                                    <li>Quick Turnaround time</li>
                                    <li>Communication and skillset of developers</li>
                                    <li>On Schedule & Quality</li>
                                    <li>NDA & Data security</li>
                                    <li>Trending technologies that suits enterprises</li>
                                    <li>Cost effective & result oriented development</li> 
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="partner_img_wrap ">
                        <ul class="d-flex  justify-content-center flex-wrap align-items-center">
                            <li class="clutch_img">
                             <img src="images/clutch-logo.png" alt="Clutch" /></li>
                             <li class="good_firms_img"><img src="images/good-firms.png" alt="Good Firms" /></li>
                             <li class="pmi_img"><img src="images/project-management-institute.png" alt="Project Management Institute" /></li>
                         </ul>
                     </div>
                 </div>
             </div>
             <div class="col-lg-5 col-md-6">
                <div class="contact-form-top" id="contact-form-top">
                    <h2>7 days <span>FREE</span><br>in the First Month
                        <small>Get in touch with us today for more information.</small></h2>
                        <form action="" method="post" class="form" id="planForm">
                            <input type="text" name="formType" id="formType" class="form-control " value="laravelDeveloper" style="display: none;">
                            <div class="form-group">
                                <input type="text" name="name" id="name" class="form-control " placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" id="email" class="form-control " placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" maxlength="11" onkeydown="return checkPhoneKey(event.key)" name="number" id="number" class="form-control " placeholder="Mobile Number">
                            </div>
                            <div class="form-group">
                                <input type="text" name="skype_id" id="skype_id" class="form-control " placeholder="Skype ID">
                            </div>
                            <div class="form-group">
                                <label for="comment">Write your message (Optional)</label>
                                <textarea class="form-control " rows="5" name="comment" id="comment"></textarea>
                            </div>
                            <div class="form-group red_btn">
                                <button class="btn" type="submit" id="make_proposal">Get A Quote Today</button>
                                <input type="hidden" name="page_url" value="<?php echo $_SESSION['REQUEST_URI'];?>">
                            </div>
                        </form>
                        <!-- <span class="form_bottom_text"><b>*8 Days Risk-Free Trial!</b></span> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Home Section End -->
    <!-- Hiring Process Start -->
    <section class="hiring_process">
        <div class="container mw-100">
            <h2 class="text-center">Website Development Company</h2>
            <div class="container">
                <div id="competencies_slider" class="owl-carousel">
                    <!-- Custom_Web Development -->
                    <div class="compe_wrapper">
                        <div class="servises_images">
                            <img src="images/custom_web.png" alt="custom_web">
                        </div>
                        <h5><span><b>Custom </b><br>Web Development</span></h5>
                    </div>
                    <!-- Custom_Web Development -->
                    <div class="compe_wrapper">
                        <div class="servises_images">
                            <img src="images/CMS_devlopment.png" alt="custom_web">
                        </div>
                        <h5><span><b>CMS </b><br>Development</span></h5>
                    </div>
                    <!-- Custom_Web Development -->
                    <div class="compe_wrapper">
                        <div class="servises_images">
                            <img src="images/e_commerce.png" alt="custom_web">
                        </div>
                        <h5><span><b>e-Commerce </b><br>Solutions</span></h5>
                    </div>
                    <!-- Custom_Web Development -->
                    <div class="compe_wrapper">
                        <div class="servises_images">
                            <img src="images/enterprise.png" alt="custom_web">
                        </div>
                        <h5><span><b>Enterprise </b><br>App development</span></h5>
                    </div>
                    <!-- Custom_Web Development -->
                    <div class="compe_wrapper">
                        <div class="servises_images">
                            <img src="images/social_networking.png" alt="custom_web">
                        </div>
                        <h5><span><b>Social</b> <br>Networking Platform<br> Development</span></h5>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hiring Process End -->
    
    <!-- case_studay section start -->
    <section class="case_studies key_highlights">
        <div class="container">
         
            <div class="listing_pg">
                <ul class="row">
                    <li class="col-md-4"> <h2>Why Choose Our Custom Website<br>
                    Development Services?</h2></li>
                    <li class="col-md-4">
                        <div>
                            <img src="images/tick-2.png">
                            <span><b>1000+</b> Clients served since 2002</span> </div>
                        </li>
                        <li class="col-md-4">
                            <div>
                                <img src="images/tick-2.png">
                                <span><b>100+</b> Skilled and Experienced Web Developers</span> </div>
                            </li>
                        </ul>
                        <ul class="row">
                            <li class="col-md-4">
                                <div>
                                    <img src="images/tick-2.png">
                                    <span><b class="text-wrapper">Step by step testing</b>Manual & Automated Testing </span> </div>
                                </li>
                                <li class="col-md-4">
                                    <div>
                                        <img src="images/tick-2.png">
                                        <span><b class="text-wrapper">Scalable</b> Solutions with cost-effective maintenance</span> </div>
                                    </li>
                                    <li class="col-md-4">
                                        <div>
                                            <img src="images/tick-2.png">
                                            <span><b class="text-wrapper">Fast Loading</b> Websites with consistent performance</span> </div>
                                        </li>
                                    </ul>
                                </div>
                                <div class="red_btn" style="
    margin-top: 80px;
    text-align: center;
    border-top: 1px solid #e6e6e6;
    padding-top: 50px;
">
                                            <a href="#contact-form-top" class="btn scroll_form">Get started now</a>
                                        </div>
                           
                        </section>
                        <!-- case_studay section end -->
                        <!-- Home Section Start -->
                        <section class="assist_sec blue_977_bg map_banner banner">
                            <div class="container text-white">
                                <div class="row">
                                   <div class="col-lg-6 col-md-6">
                                    <div class="content">
                                        <div class="why_laravel">
                                            <h2 class="text-white">Website Development<br>Company</h2>
                                            <small class="sub_title text-white">Looking to Hire Dedicated Developer for<br>Designing & Developing Your Website?</small>
                                        </div>
                                        <p>Look no further as with our web application development services, you can put a virtual face to your business and turn your idea into a scalable and profitable product.</p>
                                        <p>The only internal metric we use for our custom web design and development services is the conversion rate. By aligning our website design and development process to your business goals, we help you to not only create an online presence but also build a brand.</p>
                                        <p>We do this by putting your expectations at the heart of our website application development process. This results in a product that is intuitive, customer-centric, SEO-friendly, and conversion-optimized.</p>
                                        <div class="red_btn">
                                            <a href="#contact-form-top" class="btn scroll_form">
                                                Hire Full Stack Developer
                                            </a>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-6 col-md-6">
                                    <div class="team">
                                        <h4 class="text-center text-white">Hire Web Developer</h4>
                                        <div class="team_slider owl-carousel">
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/ashwini.jpg" alt="Ashwini" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Ashwini</h4>
                                                    <p>Laravel Developer, <span><span class="fw_600">6+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/dk.jpg" alt="Dnyaneshwar" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Dnyaneshwar</h4>
                                                    <p>Laravel Developer, <span><span class="fw_600">6+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/akshay.jpg" alt="Akshay" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Akshay</h4>
                                                    <p>AngularJs Developer, <span><span class="fw_600">5+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/nisha.jpg" alt="Nisha" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Nisha</h4>
                                                    <p>AngularJs Developer, <span><span class="fw_600">5+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/gautami.jpg" alt="Gautami" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Gautami</h4>
                                                    <p>Front End Developer, <span><span class="fw_600">4+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/amit.jpg" alt="Amit" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Amit</h4>
                                                    <p>Front End Developer, <span><span class="fw_600">5+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/pooja.jpg" alt="Pooja" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Pooja</h4>
                                                    <p>ReactJS Developer, <span><span class="fw_600">4+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/sonali.jpg" alt="Sonali" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>Sonali</h4>
                                                    <p>ReactJS Developer, <span><span class="fw_600">4+</span> exp</span></p>
                                                </div>
                                            </div>
                                            <div class="box">
                                                <div class="image">
                                                    <img src="images/shesh.jpg" alt="Sheshkumar" class="img-fluid">
                                                </div>
                                                <div class="team_info">
                                                    <h4>UI/UX Designer</h4>
                                                    <p>Laravel Developer, <span><span class="fw_600">5+</span> exp</span></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </section>
                    <!-- Home Section End -->
                    
                    <!-- INDUSTRIES SERVED -->
<section class="commen-section hiring-models">
    <div class="container text-center">
        <h2>Hiring Models<br>
            <small>Partner With Us</small>
        </h2>
        <div class="parthner-slider">
            <div id="our_parthner_slider" class="owl-carousel">
                <div class="item">
                    <div class="item-wrapper ">
                        <div class="item-wrapper-hover-1 commen-hover-box"></div>
                        <h3>Individual dedicated developer</h3>
                        <p>Hire a skilled developer who can operate remotely, equipped with standard work labs</p>
                    </div>
                </div>
                <div class="item">
                    <div class="item-wrapper">
                        <div class="item-wrapper-hover-2 commen-hover-box"></div>
                        <h3>Team of dedicated developers</h3>
                        <p>Hire a team of dedicated resources with a dedicated office space and complete control over the work process</p>
                    </div>
                </div>
                <div class="item">
                    <div class="item-wrapper ">
                        <div class="item-wrapper-hover-3 commen-hover-box"></div>
                        <h3>On-site developers</h3>
                        <p>We provide best suited on-site developers who understand the foreign work-culture</p>
                    </div>
                </div>
                <div class="item">
                    <div class="item-wrapper">
                        <div class="item-wrapper-hover-4 commen-hover-box"></div>
                        <h3>Industry-specific developers</h3>
                        <p>Hire dedicated proficient having the core IT experience of individual Industry</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Our Technology Expertise -->
                    <!-- Trusted Clients Section Start -->
                    <section class="trusted_client second_testi technology_expertise">
                        <div class="container text-center text-white">
                            <h2>Technology Expertise</h2>
                            <div class="tab_panel">
                                <!-- Nav pills -->
                                <div role="tabpanel">
                                    <ul class="nav nav-tabs" role="tablist">
                                        <li role="presentation" class="active">
                                            <a href="#frameworks" aria-controls="home" role="tab" data-toggle="tab" class="active show">Frameworks</a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#cms" aria-controls="profile" role="tab" data-toggle="tab">CMS</a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#database" aria-controls="profile" role="tab" data-toggle="tab">Database</a>
                                        </li>
                                        <li role="presentation">
                                            <a href="#js_frameworks" aria-controls="profile" role="tab" data-toggle="tab">JS</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content">
                                        <div role="tabpanel" class="tab-pane in active" id="frameworks">
                                            <!-- END -->
                                            <div class="owlCarousel frameworks_slider">
                                                <div class="frem_work " data-wow-delay="0.2s">
                                                    <img src="images/frame_work/net.png" alt="shopify" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/net-core.png" alt="net-core" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/laravel.png" alt="laravel">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/yii_framwork.png" alt="yii_framwork">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/symfony.png" alt="symfony">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/cake_php.png" alt="cake_php">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/codeigniter.png" alt="codeigniter">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/zend_framwork.png" alt="zend_framwork">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END -->
                                        <div role="tabpanel" class="tab-pane" id="cms">
                                            <div class="owlCarousel csm_fremwork_slider">
                                                <div class="frem_work">
                                                    <img src="images/frame_work/kentico-logo.png" alt="kentico" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/umbraco.png" alt="umbraco" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/share-point.png" alt="share-point" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/shopify.png" alt="shopify" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/word_press.png" alt="word_press" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/magento.png" alt="magento" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/joomla.png" alt="joomla" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/frame_work/drupalhead.png" alt="drupalhead" class="img-fluid">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END -->
                                        <div role="tabpanel" class="tab-pane" id="database">
                                            <div class="owlCarousel csm_fremwork_slider">
                                                <div class="frem_work">
                                                    <img src="images/web_development/postgresql.png" alt="postgresql" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/web_development/my-sql.png" alt="my-sql" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/web_development/sql-server.png" alt="sql-server" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/web_development/hadoop.png" alt="hadoop" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/web_development/mongo-db-design.png" alt="hadoop" class="img-fluid">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END -->
                                        <div role="tabpanel" class="tab-pane" id="js_frameworks">
                                            <div class="owlCarousel csm_fremwork_slider">
                                                <div class="frem_work">
                                                    <img src="images/front_end_development/reactlogo2.png" alt="react" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/front_end_development/angular.png" alt="angular" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/front_end_development/back_end/node.js.png" alt="node js" class="img-fluid">
                                                </div>
                                                <div class="frem_work">
                                                    <img src="images/front_end_development/back_end/main.png" alt="main js" class="img-fluid">
                                                </div>
                                            </div>
                                        </div>
                                        <!-- END -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- Trusted Clients Section End -->
                    <!-- Trusted Clients Section Start -->
                    <section class="trusted_client new-testimonilals">
                        <div class="container text-center">
                           <div class="row">
                               <div class="col-md-6">
                                <div class="clients-say">
                                   <h2>
                                    <img src="images/qute-img-left.png">
                                What Our Clients Say For Our Quality</h2>
                                <div class="top">
                                    <p class="testimonial">Your help improved our web visitors' experience on the B1G1 & made our messaging much more effective, so thank you! <span class="red_03b fw_400">- Sharon</span></p>
                                    <div class="bottom_box_testi">
                                        <ul>
                                            <li>Customer Storyboards</li>
                                            <li>Campaign Management, Integration with mailing</li>
                                            <li>Business Listings, Widgets</li>
                                        </ul>
                                    </div>
                                    <div class="star icons d-block"><img src="images/orange-star.png" alt="Star Images" /></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h2>Trusted Clients</h2>
                            <div id="trusted_partner-logo" class="logo-slider"> 
                                <div class="box">
                                    <img src="images/client/trtcle.jpg" alt="Trtcle Image" />
                                </div>
                                <div class="box">
                                    <img src="images/client/razer.jpg" alt="Razer Image" />
                                </div>
                                <div class="box">
                                    <img src="images/client/business-for-good.jpg" alt="Business for Good Image" />
                                </div>
                                <div class="box">
                                    <img src="images/client/cpenation.jpg" alt="Cpenation Image" />
                                </div>
                                <div class="box">
                                    <img src="images/client/simply-land.jpg" alt="Simply Land Image" />
                                </div>
                                <div class="box">
                                    <img src="images/client/auto-help.jpg" alt="Sauto-help Image" />
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    </div>
                    <div class="red_btn" style="margin-top: 80px;text-align: center;">
            <a href="#contact-form-top" class="btn scroll_form">Request A Quote</a></div> 
                </section>
                <!-- Trusted Clients Section End -->	
                <!-- Why eLuminous Section Start -->
                <section class="why_elu">
                    <div class="container">
                        <h2 class="text-center">Portfolio</h2>
                        <small class="sub_title text-center d-block">Hear Our Work Speak For Itself</small>
                        <ul class="portfolio_list">
                            <li><span>2000+</span> Websites Developed</li>
                            <li><span>500+</span> E-commerce Websites Developed</li>
                            <li><span>500+</span> Mobile Apps Developed</li>
                        </ul>
                        <div id="our_portfolio" class="owl-carousel">
                            <div class="" data-wow-delay="0.4s">
                                <a href="../portfolio_details/b1g1-NGO" class="overly_section cbp-caption" target="_blank">
                                    <div class="cbp-caption-defaultWrap">
                                        <img src="images/portfolio_img_4.jpg" alt="businessforgood ">
                                    </div>
                                    <div class="portfolio_discreption text-left">
                                        <h6>b1g1</h6>
                                        <p>Highly optimised website for a global NGO on a mission to create "A World Full of Giving"</p>
                                    </div>
                                </a>
                            </div>
                            <!-- GDPR compliant Website & BI solutions for Enterprise -->
                            <div class="" data-wow-delay="0.6s">
                                <a href="../portfolio_details/trtcle" class="overly_section" target="_blank">
                                    <img src="images/trtcle-thamb.jpg" alt="Web Development">
                                    <div class="portfolio_discreption text-left">
                                        <h6>TRTCLE</h6>
                                        <p>eLearning management solution for CLE (Continuiing Legal Education)</p>
                                    </div>
                                </a>
                            </div>
                            <!-- GDPR compliant Website & BI solutions for Enterprise -->
                            <div class="" data-wow-delay="0.8s">
                                <a href="../portfolio_details/angelcarebaby" class="overly_section cbp-caption" target="_blank">
                                    <img src="images/angelcarebaby.jpg" alt="Web Development">
                                    <div class="portfolio_discreption text-left">
                                        <h6>Angelcare Baby</h6>
                                        <p>Multilingual eCommerce Store For Babycare Products</p>
                                    </div>
                                </a>
                            </div>
                            <!-- GDPR compliant Website & BI solutions for Enterprise -->
                            <div class="" data-wow-delay="1s">
                                <a href="../portfolio_details/club-bookers" class="overly_section cbp-caption" target="_blank">
                                    <div class="cbp-caption-defaultWrap">
                                        <img src="images/club-bookers-thamb.jpg" alt="Web Development">
                                    </div>
                                    <div class="portfolio_discreption text-left">
                                        <h6>Club-bookers London</h6>
                                        <p>Centralized Club Booking System with Dynamic Pricing Solution</p>
                                    </div>
                                </a>
                            </div>
                            <div>
                                <a href="../portfolio_details/cosmeticplant" class="overly_section cbp-caption" target="_blank">
                                    <div class="cbp-caption-defaultWrap">
                                        <img src="images/cosmeticplant-thamb-img.jpg" alt="Web Development">
                                    </div>
                                    <div class="portfolio_discreption text-left">
                                        <h6>Cosmetic Plant</h6>
                                        <p>Online Beauty store for a beauty product manufacturer in Israel</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Pricing Section Start -->
                <section class="case_studay">
    <div class="container">
        <h2 class="text-center">Case Study</h2> 
        <div class="row m-3 mb-0">
            
            <!-- case study start HERE -->
            <div class="col-lg-6 col-xl-4 col-md-6 col-sm-6 col-12 margin-mobile-bottom">
                <div class="gray_bg">
                    <div class="row">
                        <div class="case_study_img col-sm-12 col-md-12 col-lg-12">
                            <img src="images/homeopathy.jpg" alt="case_study" class="img-fluid">
                        </div>
                        <div class="project_details col-sm-12 col-md-12 col-lg-12 ">
                            <h4>Clinic Management Solution for Asia’s Largest Homeopathy Clinic</h4>
                            
                        </div>
                        <div class="scrool_expertise text-left col-12  ">
                            <a href="images/pdf-file/homeopathy.pdf" target="_blank" class="small_blue_btn blue_big_btn_scrool">
                            <i class="fa fa-file-pdf-o" aria-hidden="true"></i> DOWNLOAD PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- case study END HERE -->

            <!-- case study start HERE -->
            <div class="col-lg-6 col-xl-4 col-md-6 col-sm-6 col-12 margin-mobile-bottom">
                <div class="gray_bg">
                    <div class="row">
                        <div class="case_study_img col-sm-12 col-md-12 col-lg-12">
                            <img src="images/women-health.jpg" alt="case_study" class="img-fluid">
                        </div>
                        <div class="project_details col-sm-12 col-md-12 col-lg-12 ">
                            <h4>Gynac Speciality Healthcare brand saw increase in footfall with IOT solution during COVID-19</h4>                           
                        </div>
                        <div class="scrool_expertise text-left col-12  ">
                            <a href="images/pdf-file/women-health-brand.pdf" target="_blank" class="small_blue_btn blue_big_btn_scrool">
                            <i class="fa fa-file-pdf-o" aria-hidden="true"></i> DOWNLOAD PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- case study END HERE -->

            <!-- case study start HERE -->
            <div class="col-lg-6 col-xl-4 col-md-6 col-sm-6 col-12 margin-mobile-bottom">
                <div class="gray_bg">
                    <div class="row">
                        <div class="case_study_img col-sm-12 col-md-12 col-lg-12">
                            <img src="images/case_study_1.jpg" alt="case_study" class="img-fluid">
                        </div>
                        <div class="project_details col-sm-12 col-md-12 col-lg-12 ">
                        <h4>IT Infrastructure Development For Smart Device Manufacturer</h4>    
                        </div>
                        <div class="scrool_expertise text-left col-12  ">
                            <a href="images/pdf-file/web-application-development.pdf" target="_blank" class="small_blue_btn blue_big_btn_scrool">
                            <i class="fa fa-file-pdf-o" aria-hidden="true"></i> DOWNLOAD PDF</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- case study END HERE -->  
            <div class="col-md-12 mt-4 mb-0">
                                    <div class="red_btn" style="text-align: center;">
            <a href="../case-studies" class="btn scroll_form">View all</a></div> 
            </div>
        </div>
    </div>
</section>
                <!-- Pricing Section Start -->
                <!-- Pricing Section Start -->
                <section class="pricing comparativeRow">
                    <div class="container">
                        <h2 class="text-center">Pricing</h2>
                        <div class="tableRow">
                            <ul class="titleRow big-title">
                                <li> </li>
                                <li>eLuminous Technologies</li>
                                <li>In - House </li>
                                <li>Freelance </li>
                            </ul>
                            <ul class="titleRow full-wrap">
                                <li>Parameter</li> 
                            </ul>
                            <ul>
                                <li>Time to get right developers</li>
                                <li>1 day - 2 weeks</li>
                                <li>4 - 12 weeks </li>
                                <li>1 - 12 weeks </li>
                            </ul>
                            <ul>
                                <li>Recurring cost of training &amp; benefits</li>
                                <li></li>
                                <li>$10,000 -$30,000</li>
                                <li>0</li>
                            </ul>
                            <ul>
                                <li>Time to scale size of team</li>
                                <li>48 hours - 1 week</li>
                                <li>4 - 16 weeks</li>
                                <li>1 - 12 weeks</li>
                            </ul>
                            <ul>
                                <li>Pricing (weekly average)</li>
                                <li>1.5 X</li>
                                <li>2X</li>
                                <li>1X</li>
                            </ul>
                            <ul>
                                <li>Project failure risk</li>
                                <li>Extremely low, we have 98% success ratio</li>
                                <li>Low</li>
                                <li>Very High</li>
                            </ul>
                            <ul>
                                <li>Dedicated resources</li>
                                <li>Yes</li>
                                <li></li>
                                <li>Some</li>
                            </ul>
                            <ul>
                                <li>Quality guarantee</li>
                                <li>Yes</li>
                                <li>High</li>
                                <li>High</li>
                            </ul>
                        </div>
                        <div class="red_btn" style="
    margin-top: 80px;
    text-align: center;
    border-top: 1px solid #e6e6e6;
    padding-top: 50px;
">
                                            <a href="#contact-form-top" class="btn scroll_form">Get started now</a>
                                        </div>
                    </div>
                </section>
                <!-- Pricing Section End -->
                <!-- FAQ Section Start -->
                <section id="faq" class="white-faq">
                    <div class="container">
                        <h2 class="text-center">Frequently Asked Questions</h2>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="panel-group accordion" id="accordion" role="tablist" aria-multiselectable="true">
                                    <div class="panel panel-default">
                                        <div class="panel-heading" role="tab" id="headingOne">
                                            <h4 class="panel-title">
                                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                 <span>01</span> Can you help me build concept of my app or website?
                                             </a>
                                         </h4>
                                     </div>
                                     <div id="collapseOne" class="panel-collapse collapse" data-parent="#accordion" role="tabpanel" aria-labelledby="headingOne" style="">
                                        <div class="panel-body">
                                            <p>
                                                At eLuminous, we believe in making software that help to improve your business. Hence we take interest in your concept, understand your business model, your competitors or reference apps and form a strategy by understanding your SWOT.
                                            </p>
                                            <p>
                                                Our Consulting experts will then bring your idea into framework or prototype that you like. After this, developers can practically roll out your beloved project concept into reality.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                              <span>02</span>  How can I be in touch with the developers according to my Time zone?
                                          </a>
                                      </h4>
                                  </div>
                                  <div id="collapseTwo" class="panel-collapse collapse  " data-parent="#accordion" role="tabpanel" aria-labelledby="headingTwo" style="">
                                    <div class="panel-body">
                                        <p>The developers are Online on Gtalk, Skype &nbsp; other Instant Messengers. For big projects, we tweak our team’s timings depending on the client’s time zone to ensure the timings don’t crumple the “communication” &nbsp; of course our “On Time Deliveries”.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingThree">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                         <span>03</span> How do I track the hours spent on my project?
                                     </a>
                                 </h4>
                             </div>
                             <div id="collapseThree" class="panel-collapse collapse  " data-parent="#accordion" role="tabpanel" aria-labelledby="headingThree" style="">
                                <div class="panel-body">
                                    <p>We understand that while you outsource the work, you always want to keep an eye on the budgeting part. Based on your preferences and size of project, we choose daily status emails, Online PMS i.e. </p>
                                    <p>
                                        Project Management Systems or using Basecamp, Mavenlink like popular time tracking and project management tools. All staff at eLuminous is fairly acquainted with above tools so that you are always aware with latest updates.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading" role="tab" id="headingFour">
                                <h4 class="panel-title">
                                    <a class="collapsed" role="button" data-toggle="collapse" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                     <span>04</span> Do I have to pay full amount at a stretch?
                                 </a>
                             </h4>
                         </div>
                         <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" data-parent="#accordion" aria-labelledby="headingFour">
                            <div class="panel-body">
                                <p>We understand that keeping everybody’s interest makes the WIN-WIN deal.
                                Payment milestones are decided based on size of the project.</p>
                                <p>
                                We work out on the payment structures depending on your project’s milestones.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="panel-group accordion" id="accordion2" role="tablist" aria-multiselectable="true">
                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingFive">
                            <h4 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    <span>05</span> What mode of payments available?
                                </a>
                            </h4>
                        </div>
                        <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" data-parent="#accordion2" aria-labelledby="headingFive">
                            <div class="panel-body">
                                <p>Our customers have the choice to pay via Bank Wire Transfer/ Bank TT, Credit Card or with your PayPal account.</p>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingSix">
                            <h4 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    <span>06</span> Will my code and Database be secure? Can you sign NDA?
                                </a>
                            </h4>
                        </div>
                        <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" data-parent="#accordion2" aria-labelledby="headingSix">
                            <div class="panel-body">
                                <p>eLuminous has handled a large variety of sensitive information including millions of CC numbers, emails and details of your customers as well.</p>
                                <p> At eLuminous, our business is based on strong ethical foundation and we take decisions based on highest level of ethical integrity and our Core Values. We welcome signing NDA (Non-Disclosure Agreement) as needed.</p>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading" role="tab" id="headingSeven">
                            <h4 class="panel-title">
                                <a class="collapsed" role="button" data-toggle="collapse" href="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                 <span>07</span> What if I face after delivery bugs?
                             </a>
                         </h4>
                     </div>
                     <div id="collapseSeven" class="panel-collapse collapse" role="tabpanel" data-parent="#accordion2" aria-labelledby="headingSeven">
                        <div class="panel-body">
                            <p>We provide 30 days FREE service from beta delivery of your application. Hence you can relax as even if any bugs arises, it won’t eat your pocket.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</section>
<!-- FAQ Section End -->
<section class="our_partner">
    <div class="container">
        <!-- Why eLuminous Section End -->
        <div class=" last-wrapper-row-footer">
            <h2 class="text-center">Our Esteemed Partners</h2>
            <div class="row custom-row-wrapper-box">
                <div class="footer-logos-wrapper">
                    <div class="clutch-widget-wrapper">
                        <script type="text/javascript" src="https://widget.clutch.co/static/js/widget.js"></script>
                        <div class="clutch-widget" data-url="https://widget.clutch.co" data-widget-type="2" data-height="50" data-clutchcompany-id="432429"><iframe id="iframe-0.9791840081512366" style="border: medium none; display: block;" src="https://widget.clutch.co/widgets/get/2?ref_domain=eluminoustechnologies.com&amp;uid=432429&amp;ref_path=/web-application-development" title="eLuminous Technologies Pvt Ltd Clutch Review Widget 2" width="100%" height="50px"></iframe></div>
                    </div>
                    <div class="mobile-app-logo">
                        <a href="https://www.topdevelopers.co/directory/mobile-app-developers" target="_blank"> <img src="https://eluminoustechnologies.com/images/home/Badges-Mobile-App-Developers-2020.png" alt="Gartner" /></a>
                    </div>
                    <div class="goodfirms"><a target="_blank" href="https://www.goodfirms.co/companies/view/6738/eluminous-technologies-pvt-ltd"><img style="width:243px" src="https://assets.goodfirms.co/categories/goodfirms-blue.svg" alt="GoodFirms Badge" /></a>
                    </div>
                    <div class="logo-itfirms"><a href="https://www.itfirms.co/top-web-development-companies/" target="_blank"><img src="https://www.itfirms.co/wp-content/uploads/2020/01/app-developers-usa-2020.png" alt="itfirms" /></a></div>
                    <div class="gartner-logo">
                        <img src="https://eluminoustechnologies.com/images/home/gartner-logo.png" alt="Gartner">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- contact-form -->
<section class="first-month-wrapper">
   <div class="container">
    <h2>Book A Free Consultation Call Today</h2>
    <p>Let's discuss, and create something unique and amazing for your business! Today is the Time!</p>
    <div class="form-group red_btn">
      <!--   <a href="#main-head" class="scrollToTopas btn">Book Your Slot Now!</a> -->
      <h1>Book Your Slot Now</h1>
         <form action="" method="post" class="form" id="bookForm">
                            <input type="text" name="formType" id="formType" class="form-control " value="laravelDeveloper" style="display: none;">
                            <div class="form-group">
                                <input type="text" name="name" id="name" class="form-control " placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" id="email" class="form-control " placeholder="Email">
                            </div>
                          
                            <div class="form-group">
                                <input type="text" name="dateday" id="dateday"  placeholder="dd-mm-yyyy"> <span id="error_dateday" class="red"></span>
                            </div>
                            <div class="form-group">
                                <span id="datetime"></span>
                            </div>
                           
                            <div class="form-group red_btn">
                                <button class="btn" type="submit" id="make_proposal">Book Now!</button>
                                <input type="hidden" name="page_url" value="<?php echo $_SESSION['REQUEST_URI'];?>">
                            </div>
                        </form>
    </div>
</div>
</section>
<?php require_once("includes/footer.php");?>
