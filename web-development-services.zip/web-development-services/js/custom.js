function setHeaderSticky() {
    if ($(window).scrollTop() >= 80) {
        $("header").addClass("sticky");
    } else {
        $("header").removeClass("sticky");
    }
}
$(window).scroll(function() {
    setHeaderSticky();
});

$(window).on("load", function() {
    setHeaderSticky();
});
$(document).ready(function() {
    // Sticky Header Js
    // $(window).scroll(function() {
    //     if ($(window).scrollTop() >= 1) {
    //         $('header').addClass('sticky');
    //     } else {
    //         $('header').removeClass('sticky');
    //     }
    // });

    // Counter Js
    $(".counter").countUp();

    // SrollTop Js
    $(function() {
        var $ele = $(".scrollToTop");

        $(window).scroll(function() {
            $(this).scrollTop() >= 100 ?
                $ele.show(1).animate({
                        right: "10px",

                        opacity: "1"
                    },
                    1
                ) :
                $ele.animate({
                        right: "-50px",

                        opacity: "0"
                    },
                    1
                );
        });

        $ele.click(function(e) {
            e.preventDefault();

            $("html,body").animate({
                    scrollTop: 0
                },
                600
            );
        });
    });

    $("#trusted_partner").owlCarousel({
        loop: true,
        margin: 15,
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        responsive: {
            0: {
                items: 2
            },
            576: {
                items: 3
            },
            768: {
                items: 4
            },
            1000: {
                margin: 35,
                items: 5
            }
        }
    }); 
$('#our_parthner_slider').owlCarousel({
loop:true,
margin:15,
nav:true,
responsive:{
    0:{
        items:1
    },
    640:{
        items:2
    },
    768:{
        items:3
        },
    1220:{
        items:4
        }
    }
});
    $("#elu_slider").owlCarousel({
        loop: true,
        margin: 5,
        animateIn: "fadeIn",
        animateOut: "fadeOut",
        nav: false,
        dots: false,
        autoplay: true,
        autoplayTimeout: 3000,
        autoplayHoverPause: false,
        responsive: {
            0: {
                items: 1
            }
        }
    });

    // Team Slider Js
    $(".team_slider").owlCarousel({
        loop: true,
        items: 1,
        margin: 0,
        autoplay: true,
        autoplayTimeout: 3000,
        itemsDesktop: [1000, 1],
        itemsDesktopSmall: [979, 2],
        itemsTablet: [768, 2],
        itemsMobile: [650, 1],
        pagination: true,
        autoPlay: true
    });

    // case studies Slider Js
    $(".studies_slider").owlCarousel({
        loop: true,
        margin: 0,
        nav: false,
        dots: true,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: false,
        responsive: {
            0: {
                items: 1
            },
            576: {
                items: 2
            },
            768: {
                items: 3,
                autoplay: false,
                dots: false
            }
        }
    });

    new WOW().init();

    // $('.scroll_form').on('click', function(event) {
    //     $(".nav_two a").removeClass('active');
    //     $(this).addClass('active');
    //     var target = $($(this).attr('href'));
    //     if (target.length) {
    //         event.preventDefault();
    //         $('html, body').animate({
    //             scrollTop: target.offset().top - 300
    //         }, 800)
    //     }
    // });

    // $(window).scroll(function() {
    //     if (
    //         $(window).scrollTop() + $(window).height() >
    //         $(document).height() - 78
    //     ) {
    //         //
    //         $("#quote").css({ bottom: "78px" });
    //         // $('#floatingcontactcta').animate({bottom:'70px'},1000);
    //     } else {
    //         $("#quote").css({ bottom: "0" });
    //     }
    // });

    $(".scroll_form").click(function() {
        $("html, body")
            .stop()
            .animate({
                    scrollTop: $($(this).attr("href")).offset().top - 140
                },
                600
            );
        setTimeout(function() {
            $("#contact-form-top").addClass("animated bounce");
        }, 600);

        setTimeout(function() {
            $("#contact-form-top").removeClass("animated bounce");
        }, 6000);
    });
    $("#competencies_slider").owlCarousel({
		loop: !0,
		margin: 0,
		autoplay: !0,
		nav: !1,
		autoplayTimeout: 3e3,
		responsiveClass: !0,
		responsive: {
			0: {
				items: 1,
				loop: !0
			},
			540: {
				items: 1,
				loop: !1
			},
			541: {
				items: 2,
				loop: !1
			},
			860: {
				items: 3,
				loop: !1
			},
			1400: {
				items: 4,
				loop: !1
			},
			1600: {
				items: 5,
				loop: !1
			}
		}
    });
    $(".frameworks_slider").owlCarousel({
		loop: !0,
		autoplay: !0,
		nav: !0,
		loop: !0,
		autoplayTimeout: 3e3,
		responsiveClass: !0,
		navText: ['<img src="images/home/arrow-previous.png" alt="arrow-previous">', '<img src="images/home/arrow-next.png" alt="arrow-next">'],
		responsive: {
			0: {
				items: 2,
				loop: !0
			},
			480: {
				items: 3,
				loop: !0
			},
			768: {
				items: 4,
				loop: !0
			},
			1200: {
				items: 5,
				loop: !0
			},
			1400: {
				items: 6,
				loop: !0
			}
		}
	});
    $(".csm_fremwork_slider").owlCarousel({
		loop: !0,
		autoplay: !0,
		nav: !1,
		autoplayTimeout: 3e3,
		margin: 0,
		responsiveClass: !0,
		responsive: {
			0: {
				items: 2,
				loop: !0
			},
			700: {
				items: 4,
				loop: !1
			},
			1100: {
				items: 4,
				loop: !1
			}
		}
	});
    $("#our_portfolio").owlCarousel({
		loop: !0,
		margin: 20,
		autoplay: !0,
		nav: !1,
		autoplayTimeout: 3e3,
		responsiveClass: !0,
		responsive: {
			0: {
				items: 1,
				loop: !0
			},
			600: {
				items: 2,
				loop: !1
			},
			1e3: {
				items: 3,
				loop: !1
			},
			1200: {
				items: 4,
				loop: !1
			}
		}
	});
});